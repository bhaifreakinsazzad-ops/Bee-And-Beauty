# Bee & Beauty Shopify Theme

This is a Shopify OS 2.0 theme conversion of the supplied Bee & Beauty storefront preview and downloaded source bundle. It includes the original supplied image assets, responsive homepage sections, configurable product-picker blocks, Shopify cart/product forms, search panel, wishlist toggles, shade-match interaction, camera permission flow, kit builder, navigation, footer, and Shopify theme settings.

## Import
1. Zip the contents of this folder (the `layout`, `sections`, `snippets`, `templates`, `config`, `assets`, and `locales` folders must be at the archive root).
2. In Shopify admin go to **Online Store → Themes → Add theme → Upload zip file**.
3. Connect the theme's product-picker blocks to your Shopify products/collections in the theme editor. A theme zip cannot create Shopify catalog records, inventory, shipping, payments, or customer accounts; those remain store-admin data.

## Fidelity notes
The preview was a React/Vite storefront with product data embedded in its source. This conversion preserves the supplied hero, logo, category, editorial, founder, and product imagery locally. Shopify product blocks accept a real product reference and fall back to the matched source copy/imagery when left unconnected, so the visual storefront is useful immediately and becomes commerce-functional once products are connected.
